<?php
fwrite(STDOUT, 'successful');
?>