<?php
$config_ssh_port = 22;
$config_ssh_username = '';
$config_ssh_password = '';
?>