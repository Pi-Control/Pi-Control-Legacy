<?php
$site = array(
	'install' => 'install.php',
	'install_check' => 'install_check.php',
	'install_connection' => 'install_connection.php',
	'install_settings' => 'install_settings.php',
	'install_create' => 'install_create.php'
);
?>